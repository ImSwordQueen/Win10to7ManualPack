Windows 7 explorer for Windows 8 (Ex7ForW8)
===========================================
Version 1.0
-----------

This program is created by Tihiy (simplestas@nm.ru).
You can't redistribute this program without mentionting me.
You can't redistribute this program without this readme.txt file. You also can't modify it.

If you want to deploy silent installation, refer to scripting guide which you can download from:
http://tihiy.net/files/Ex7forW8_scripting.zip

THIS PROGRAM IS PROVIDED TO YOU "AS IS" AND I'M NOT RESPONSIBLE FOR ANY DAMAGES!

WHAT IS THIS PROGRAM
====================
This program restores native Windows 7 start menu and desktop by bringing Windows 7 explorer.exe.
Start menu retains full configurability you expect from Windows 7 start menu.
This program includes sophisticated lightweight wrapper, install/uninstall/patch program.
You can use it on Windows 8 or Windows Server 2012 RTM or RP versions, any version, any language.

PRECAUTIONS
===========
This program does not modify system files and system protected registry entries.
You can switch back to unaltered Windows 8 UI any time. 
Windows 7 shell is enabled only to users which switched to it.
Other users can use Windows 8 shell without any problems.

LIMITATIONS
===========
* Metro (Modern) UI is not loaded into memory. As a bonus you save dozens MB of RAM.
* Metro UI screens and programs are unavailable.
* Toasts (like "You have new program to handle this stuff") won't show. You need to use Default programs to change associations. 
* You may get more UAC prompts.
* No default language input indicator. Enable language bar via Control Panel->Language->Advanced Settings->Use desktop language bar.
* No multi-monitor taskbars. Maybe more multimon issues.
* No immersive hotkeys (Win+X, Win+PrtScr too).
* To add new user, run netplwiz.exe.

INSTALLATION
============
Launch Ex7ForW8_setup.exe. Follow instructions.
You'll need Windows 7 installation DVD or files ready; keep in mind that they should be same language and bitness. 

Ex7forW8 install requires admin privileges. Users without admin rights should 'Run as administrator' it.
After installation, shell can be configured by all users for themselves, without administrator rights.

UNINSTALLATION
==============
Uninstall program from Programs and Features. If you're using portable install, just switch shell to Windows 8 and delete folder.
Uninstallation requires administrator rights.

WHERE TO GET SUPPORT
====================
http://www.msfn.org/board/topic/157302-windows-7-explorer-for-windows-8/
http://forums.mydigitallife.info/threads/35189-Windows-7-explorer-for-Windows-8

I will not answer stupid questions on my mail.

DONATE
======
If you like this work and want Windows 8 improved, please donate. Click donation link in the app.

VERSION HISTORY
===============
1.0 - 30 sep 2012
*****************
- Installer: can create shortcuts for all users or only this user
- Tool: now properly switches shells for non-admin users
- Explorer7: fixed MFU list displaying duplicate items; fixed minor memory leak

0.9RC - 26 sep 2012
*******************
- Tool: accepts en-US mui files as fallback for any language
- Tool: improved open speed (does not try to patch explorer each time)
- Tool: command line options (see scripting guide)
- Explorer7: fixed 'Exit explorer' not unloading explorer.exe fully

0.8RC - 24 sep 2012
*******************
- New, automated GUI installer / patcher
- Explorer7/8 are treated as the same program on taskbar; no need to re-pin
- "Pin to Start Menu" strings are localized from shell32.dll.mui

BETA7 - 11 sep 2012
*******************
- Tray icon settings are stored separately for explorer7; wipe no longer needed
- Show Desktop button has different style
- Windows logon sound is always played

BETA6 - 06 sep 2012
*******************
- Fix: shell could crash if broken shortcuts were on desktop
- AutoPlay now works (no toast)
- Win-P now works
- Other minor improvements

BETA5 - 31 aug 2012
*******************
- MFU list: improved performance
- MFU list: now collects shortcuts from desktop too
- Network systray icon works (Metro UI)
- Fix: Alt-Tab window didn't show application icons

BETA4
*******************
- Pin list reimplemented
- MFU list reimplemented

BETA3
*******************
- RTM theme fixed

BETA2
*******************
- Fix: Log off / Lock etc weren't displayed in shutdown flyout
- Alt-Tab window works

BETA1
*******************
- x64 support
- Tray icon customization works

BETA0
*******************
- First public release
