replace both in the install directory of openwithenhanced and add the following to the hosts file:

127.0.0.1 extensions.frieger.com